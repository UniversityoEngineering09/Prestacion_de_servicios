import axios from 'axios';
import type { Prestamo } from '../types/prestamo';

const API_URL = 'https://localhost:7284/api/Prestamos';

export const getPrestamos = () => axios.get(API_URL).then(res => res.data);
export const getPrestamo = (id: number) => axios.get(`${API_URL}/${id}`).then(res => res.data);
export const createPrestamo = (prestamo: Omit<Prestamo, 'id' | 'totalAPagar' | 'estaPagado'>) =>
  axios.post(API_URL, prestamo).then(res => res.data);
export const updatePrestamo = (id: number, prestamo: Prestamo) =>
  axios.put(`${API_URL}/${id}`, prestamo);
export const deletePrestamo = (id: number) => axios.delete(`${API_URL}/${id}`);
