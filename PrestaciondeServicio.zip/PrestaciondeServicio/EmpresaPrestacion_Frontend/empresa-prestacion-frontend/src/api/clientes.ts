import axios from 'axios';
import type { Cliente, ClienteCreate } from '../types/cliente';

const API_URL = 'https://localhost:7284/api/Clientes';

export const getClientes = () =>
  axios.get<Cliente[]>(API_URL).then(res => res.data);

export const getCliente = (id: number) =>
  axios.get<Cliente>(`${API_URL}/${id}`).then(res => res.data);

export const createCliente = (data: ClienteCreate) =>
  axios.post<Cliente>(API_URL, data).then(res => res.data);

export const updateCliente = (id: number, data: ClienteCreate) =>
  axios.put(`${API_URL}/${id}`, data);

export const deleteCliente = (id: number) =>
  axios.delete(`${API_URL}/${id}`);
