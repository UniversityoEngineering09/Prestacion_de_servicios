import axios from 'axios';
import type { Pago } from '../types/pago';

const API_URL = 'https://localhost:7284/api/Pagos';

export const getPagos = () => axios.get(API_URL).then(res => res.data);
export const getPago = (id: number) => axios.get(`${API_URL}/${id}`).then(res => res.data);
export const createPago = (pago: Omit<Pago, 'id'>) => axios.post(API_URL, pago).then(res => res.data);
export const updatePago = (id: number, pago: Pago) => axios.put(`${API_URL}/${id}`, pago);
export const deletePago = (id: number) => axios.delete(`${API_URL}/${id}`);
