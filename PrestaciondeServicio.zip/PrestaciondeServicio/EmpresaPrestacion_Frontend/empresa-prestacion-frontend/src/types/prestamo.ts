export interface Prestamo {
  id: number;
  clientesId: number;
  monto: number;
  plazoMeses: number;
  tasaInteres: number;
  totalAPagar: number;
  estaPagado: boolean;
}
