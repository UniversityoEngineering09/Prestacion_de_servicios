export interface Cliente {
  id: number;
  nombre: string;
  correo: string;
}

export interface ClienteCreate {
  nombre: string;
  correo: string;
}
