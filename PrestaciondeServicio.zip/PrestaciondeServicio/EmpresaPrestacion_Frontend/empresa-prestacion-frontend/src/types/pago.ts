export interface Pago {
  id: number;
  prestamoId: number;
  montoPagado: number;
  fechaPago: string; // ISO string
}
