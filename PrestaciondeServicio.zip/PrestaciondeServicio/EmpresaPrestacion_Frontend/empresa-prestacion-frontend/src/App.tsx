import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import ClientesList from './pages/Clientes/ClientesList';
import ClienteForm from './pages/Clientes/ClienteForm';
import PrestamosList from './pages/Prestamos/PrestamosList';
import PrestamoForm from './pages/Prestamos/PrestamoForm';
import PagosList from './pages/Pagos/PagoList';
import PagoForm from './pages/Pagos/PagoForm';
import Home from './pages/Home';

function App() {
  return (
    <Router>
      <NavBar />
      <div className="container mt-4">
        <Routes>
          {/* <Route path="/" element={<ClientesList />} />*/}
          
          <Route path="/clientes" element={<ClientesList />} />
          <Route path="/clientes/crear" element={<ClienteForm />} />
          <Route path="/clientes/editar/:id" element={<ClienteForm />} />

          <Route path="/prestamos" element={<PrestamosList />} />
          <Route path="/prestamos/crear" element={<PrestamoForm />} />
          <Route path="/prestamos/editar/:id" element={<PrestamoForm />} />

          <Route path="/pagos" element={<PagosList />} />
          <Route path="/pagos/crear" element={<PagoForm />} />
          <Route path="/pagos/editar/:id" element={<PagoForm />} />
          <Route path="/" element={<Home />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
