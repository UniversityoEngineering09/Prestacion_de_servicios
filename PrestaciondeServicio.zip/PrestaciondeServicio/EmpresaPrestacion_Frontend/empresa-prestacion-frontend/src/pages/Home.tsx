import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="text-center mt-5">
      <h1 className="display-4">Bienvenido a Empresa de Prestaciones</h1>
      <p className="lead">Administra clientes, préstamos y pagos de forma eficiente.</p>
      <hr className="my-4" />
      <div className="d-flex justify-content-center gap-3">
        <Link to="/clientes" className="btn btn-primary btn-lg">Ir a Clientes</Link>
        <Link to="/prestamos" className="btn btn-success btn-lg">Ver Préstamos</Link>
        <Link to="/pagos" className="btn btn-info btn-lg">Historial de Pagos</Link>
      </div>
    </div>
  );
};

export default Home;
