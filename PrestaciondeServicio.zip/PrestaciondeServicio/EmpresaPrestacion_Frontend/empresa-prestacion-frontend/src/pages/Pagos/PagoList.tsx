// PagosList.tsx
import { useEffect, useState } from 'react';
import { getPagos, deletePago } from '../../api/pagos';
import type { Pago } from '../../types/pago';
import { Link } from 'react-router-dom';

const PagosList = () => {
  const [pagos, setPagos] = useState<Pago[]>([]);

  useEffect(() => {
    getPagos().then(setPagos);
  }, []);

  const handleDelete = async (id: number) => {
    await deletePago(id);
    setPagos(pagos.filter(p => p.id !== id));
  };

  return (
    <div className="container mt-4">
      <h2>Historial de Pagos</h2>
      <Link to="/pagos/crear" className="btn btn-success mb-3">Registrar Pago</Link>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>ID Préstamo</th>
            <th>Monto Pagado</th>
            <th>Fecha</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {pagos.map(p => (
            <tr key={p.id}>
              <td>{p.prestamoId}</td>
              <td>${p.montoPagado}</td>
              <td>{new Date(p.fechaPago).toLocaleDateString()}</td>
              <td>
                <Link to={`/pagos/editar/${p.id}`} className="btn btn-sm btn-primary">Editar</Link>
                <button onClick={() => handleDelete(p.id)} className="btn btn-sm btn-danger ms-2">Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PagosList;
