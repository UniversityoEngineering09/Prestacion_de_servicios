// PagoForm.tsx
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createPago, getPago, updatePago } from '../../api/pagos';
import type { Pago } from '../../types/pago';

const PagoForm = () => {
  const [pago, setPago] = useState<Omit<Pago, 'id'>>({
    prestamoId: 0,
    montoPagado: 0,
    fechaPago: new Date().toISOString().slice(0, 10),
  });

  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      getPago(+id).then((p) => {
        const { id: _id, ...rest } = p;
        setPago(rest);
      });
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPago({ ...pago, [name]: name === 'montoPagado' || name === 'prestamoId' ? +value : value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (id) {
      await updatePago(+id, { ...pago, id: +id });
    } else {
      await createPago(pago);
    }
    navigate('/pagos');
  };

  return (
    <div className="container mt-4">
      <h2>{id ? 'Editar Pago' : 'Nuevo Pago'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">ID Préstamo</label>
          <input name="prestamoId" type="number" className="form-control" value={pago.prestamoId} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Monto Pagado</label>
          <input name="montoPagado" type="number" className="form-control" value={pago.montoPagado} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Fecha de Pago</label>
          <input name="fechaPago" type="date" className="form-control" value={pago.fechaPago} onChange={handleChange} required />
        </div>
        <button type="submit" className="btn btn-primary">Guardar</button>
      </form>
    </div>
  );
};

export default PagoForm;
