import { useEffect, useState } from 'react';
import { getClientes, deleteCliente } from '../../api/clientes';
import type { Cliente } from '../../types/cliente';
import { Link } from 'react-router-dom';

export default function ClientesList() {
  const [clientes, setClientes] = useState<Cliente[]>([]);

  useEffect(() => {
    getClientes().then(setClientes);
  }, []);

  const eliminar = async (id: number) => {
    if (confirm('¿Seguro que deseas eliminar este cliente?')) {
      await deleteCliente(id);
      setClientes(clientes.filter(c => c.id !== id));
    }
  };

  return (
    <div className="container mt-4">
      <h2>Clientes</h2>
      <Link to="/clientes/crear" className="btn btn-primary mb-3">Nuevo Cliente</Link>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {clientes.map(cliente => (
            <tr key={cliente.id}>
              <td>{cliente.id}</td>
              <td>{cliente.nombre}</td>
              <td>{cliente.correo}</td>
              <td>
                <Link to={`/clientes/editar/${cliente.id}`} className="btn btn-warning btn-sm me-2">Editar</Link>
                <button onClick={() => eliminar(cliente.id)} className="btn btn-danger btn-sm">Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
