import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import type { ClienteCreate } from '../../types/cliente';
import { createCliente, getCliente, updateCliente } from '../../api/clientes';

export default function ClienteForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState<ClienteCreate>({ nombre: '', correo: '' });

  useEffect(() => {
    if (id) {
      getCliente(Number(id)).then(data => setForm({ nombre: data.nombre, correo: data.correo }));
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (id) await updateCliente(Number(id), form);
    else await createCliente(form);
    navigate('/clientes');
  };

  return (
    <div className="container mt-4">
      <h2>{id ? 'Editar Cliente' : 'Crear Cliente'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Nombre</label>
          <input name="nombre" className="form-control" value={form.nombre} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Correo</label>
          <input name="correo" type="email" className="form-control" value={form.correo} onChange={handleChange} required />
        </div>
        <button className="btn btn-success" type="submit">Guardar</button>
        <button className="btn btn-secondary ms-2" onClick={() => navigate('/clientes')}>Cancelar</button>
      </form>
    </div>
  );
}
