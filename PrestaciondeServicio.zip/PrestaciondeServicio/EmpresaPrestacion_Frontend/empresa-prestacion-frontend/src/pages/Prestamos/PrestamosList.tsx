import { useEffect, useState } from 'react';
import { getPrestamos, deletePrestamo } from '../../api/prestamos';
import type { Prestamo } from '../../types/prestamo';
import { Link } from 'react-router-dom';

const PrestamosList = () => {
  const [prestamos, setPrestamos] = useState<Prestamo[]>([]);

  useEffect(() => {
    getPrestamos().then(setPrestamos);
  }, []);

  const handleDelete = async (id: number) => {
    await deletePrestamo(id);
    setPrestamos(prestamos.filter(p => p.id !== id));
  };

  return (
    <div className="container mt-4">
      <h2>Lista de Préstamos</h2>
      <Link to="/prestamos/crear" className="btn btn-success mb-3">Nuevo Préstamo</Link>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Cliente ID</th>
            <th>Monto</th>
            <th>Plazo</th>
            <th>Interés (%)</th>
            <th>Total a Pagar</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {prestamos.map(p => (
            <tr key={p.id}>
              <td>{p.clientesId}</td>
              <td>${p.monto}</td>
              <td>{p.plazoMeses} meses</td>
              <td>{p.tasaInteres}</td>
              <td>${p.totalAPagar}</td>
              <td>{p.estaPagado ? 'Pagado' : 'Pendiente'}</td>
              <td>
                <Link to={`/prestamos/editar/${p.id}`} className="btn btn-sm btn-primary">Editar</Link>
                <button onClick={() => handleDelete(p.id)} className="btn btn-sm btn-danger ms-2">Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PrestamosList;
