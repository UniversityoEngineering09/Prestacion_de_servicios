// PrestamoForm.tsx
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createPrestamo, getPrestamo, updatePrestamo } from '../../api/prestamos';
import type { Prestamo } from '../../types/prestamo';

const PrestamoForm = () => {
  const [prestamo, setPrestamo] = useState<Omit<Prestamo, 'id' | 'totalAPagar' | 'estaPagado'>>({
    clientesId: 0,
    monto: 0,
    plazoMeses: 6,
    tasaInteres: 5,
  });

  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    if (id) {
      getPrestamo(+id).then((p) => {
        const { id: _id, totalAPagar, estaPagado, ...rest } = p;
        setPrestamo(rest);
      });
    }
  }, [id]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPrestamo({ ...prestamo, [name]: name === 'clientesId' || name === 'plazoMeses' || name === 'monto' || name === 'tasaInteres' ? +value : value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (id) {
      await updatePrestamo(+id, { ...prestamo, id: +id, totalAPagar: 0, estaPagado: false });
    } else {
      await createPrestamo(prestamo);
    }
    navigate('/prestamos');
  };

  return (
    <div className="container mt-4">
      <h2>{id ? 'Editar Préstamo' : 'Nuevo Préstamo'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">ID Cliente</label>
          <input name="clientesId" type="number" className="form-control" value={prestamo.clientesId} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Monto</label>
          <input name="monto" type="number" className="form-control" value={prestamo.monto} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Plazo (meses)</label>
          <select name="plazoMeses" className="form-select" value={prestamo.plazoMeses} onChange={handleChange} required>
            <option value={6}>6 meses</option>
            <option value={12}>12 meses</option>
            <option value={18}>18 meses</option>
            <option value={24}>24 meses</option>
          </select>
        </div>
        <div className="mb-3">
          <label className="form-label">Tasa de Interés (%)</label>
          <input name="tasaInteres" type="number" className="form-control" value={prestamo.tasaInteres} onChange={handleChange} required />
        </div>
        <button type="submit" className="btn btn-primary">Guardar</button>
      </form>
    </div>
  );
};

export default PrestamoForm;