
--CREATE DATABASE EmpresaPrestacion;

INSERT INTO Clientes (Nombre, Correo)
VALUES 
('Juan P�rez', 'juan@example.com'),
('Ana Mart�nez', 'ana@example.com'),
('Carlos G�mez', 'carlos@example.com');


-- Juan P�rez - 12 meses, 5% inter�s
INSERT INTO Prestamos (ClientesId, Monto, PlazoMeses, TasaInteres, TotalAPagar, EstaPagado)
VALUES (1, 10000, 12, 5.00, ROUND(10000 * POWER(1 + 0.05, 12), 2), 0);

-- Ana Mart�nez - 6 meses, 4% inter�s
INSERT INTO Prestamos (ClientesId, Monto, PlazoMeses, TasaInteres, TotalAPagar, EstaPagado)
VALUES (2, 5000, 6, 4.00, ROUND(5000 * POWER(1 + 0.04, 6), 2), 0);

-- Carlos G�mez - 24 meses, 6% inter�s
INSERT INTO Prestamos (ClientesId, Monto, PlazoMeses, TasaInteres, TotalAPagar, EstaPagado)
VALUES (3, 20000, 24, 6.00, ROUND(20000 * POWER(1 + 0.06, 24), 2), 0);


-- Juan P�rez ha pagado parcialmente
INSERT INTO Pagos (PrestamoId, MontoPagado, FechaPago)
VALUES
(1, 2000, GETDATE()),
(1, 1500, GETDATE());

-- Ana Mart�nez ha pagado todo
INSERT INTO Pagos (PrestamoId, MontoPagado, FechaPago)
VALUES
(2, 3000, GETDATE()),
(2, 2500, GETDATE());

-- Carlos G�mez a�n no paga


SELECT * FROM Clientes;
SELECT * FROM Pagos;
SELECT * FROM Prestamos

