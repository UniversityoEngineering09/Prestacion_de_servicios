﻿using System.ComponentModel.DataAnnotations;
namespace EmpresaPrestacion.Models
{
    public class Prestamo
    {
        [Key]
        public int Id { get; set; }

        [Required, Range(1, 1000)]
        public int ClientesId { get; set; }

        public Clientes Clientes { get; set; } = null!;

        [Required, Range(100, 1000000000)]
        public decimal Monto { get; set; }

        [Required, Range(6, 24)]
        public int PlazoMeses { get; set; }

        [Required, Range(0.01, 100)]
        public decimal TasaInteres { get; set; }

        [Required]
        public decimal TotalAPagar { get; set; }

        public bool EstaPagado { get; set; }

        public List<Pago> Pagos { get; set; } = new();
    }
}

