﻿using System.ComponentModel.DataAnnotations;

namespace EmpresaPrestacion.Models
{
    public class Clientes
    {
        [Key]
        public int Id { get; set; }

        [Required, MaxLength(25)]
        public string Nombre { get; set; } = "";

        [Required, MaxLength(25)]
        public string Correo { get; set; } = "";

        public List<Prestamo> Prestamos { get; set; } = new();
    }
}
