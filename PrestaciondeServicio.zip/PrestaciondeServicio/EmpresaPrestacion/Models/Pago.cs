﻿using System.ComponentModel.DataAnnotations;
namespace EmpresaPrestacion.Models
{
    public class Pago
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int PrestamoId { get; set; }

        public Prestamo Prestamo { get; set; } = null!;

        [Required, Range(1, 1000000000)]
        public decimal MontoPagado { get; set; }

        [Required]
        public DateTime FechaPago { get; set; } = DateTime.Now;
    }
}
