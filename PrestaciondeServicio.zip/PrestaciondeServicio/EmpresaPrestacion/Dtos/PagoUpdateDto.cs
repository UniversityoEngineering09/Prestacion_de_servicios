﻿namespace EmpresaPrestacion.Dtos
{
    public class PagoUpdateDto
    {
        public decimal MontoPagado { get; set; }
    }
}
