﻿namespace EmpresaPrestacion.Dtos
{
    public class PagoDto
    {
        public int Id { get; set; }
        public int PrestamoId { get; set; }
        public decimal MontoPagado { get; set; }
        public DateTime FechaPago { get; set; }
    }
}
