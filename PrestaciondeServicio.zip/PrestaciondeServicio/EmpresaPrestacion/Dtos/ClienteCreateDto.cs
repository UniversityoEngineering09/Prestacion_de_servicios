﻿namespace EmpresaPrestacion.Dtos
{
    public class ClienteCreateDto
    {
        public string Nombre { get; set; } = "";
        public string Correo { get; set; } = "";
    }
}
