﻿namespace EmpresaPrestacion.Dtos
{
    public class PrestamoDto
    {
        public int Id { get; set; }
        public int ClientesId { get; set; }
        public decimal Monto { get; set; }
        public int PlazoMeses { get; set; }
        public decimal TasaInteres { get; set; }
        public decimal TotalAPagar { get; set; }
        public bool EstaPagado { get; set; }
    }
}
