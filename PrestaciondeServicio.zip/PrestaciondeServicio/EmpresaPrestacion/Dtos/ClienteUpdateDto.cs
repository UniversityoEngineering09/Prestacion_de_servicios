﻿namespace EmpresaPrestacion.Dtos
{
    public class ClienteUpdateDto
    {
        public string Nombre { get; set; } = "";
        public string Correo { get; set; } = "";
    }
}
