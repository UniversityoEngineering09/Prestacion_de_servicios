﻿namespace EmpresaPrestacion.Dtos
{
    public class PrestamoCreateDto
    {
        public int ClientesId { get; set; }
        public decimal Monto { get; set; }
        public int PlazoMeses { get; set; }
        public decimal TasaInteres { get; set; }
    }
}
