﻿namespace EmpresaPrestacion.Dtos
{
    public class PagoCreateDto
    {
        public int PrestamoId { get; set; }
        public decimal MontoPagado { get; set; }
    }
}
