﻿using EmpresaPrestacion.Models;
using Microsoft.EntityFrameworkCore;

namespace EmpresaPrestacion.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> opciones) : base(opciones) { }

        public DbSet<Clientes> Clientes { get; set; } = null!;
        public DbSet<Prestamo> Prestamos { get; set; } = null!;
        public DbSet<Pago> Pagos { get; set; } = null!;
    }
}
