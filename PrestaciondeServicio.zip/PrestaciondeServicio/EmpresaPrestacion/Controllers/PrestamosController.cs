﻿using EmpresaPrestacion.Data;
using EmpresaPrestacion.Dtos;
using EmpresaPrestacion.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmpresaPrestacion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrestamosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PrestamosController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Prestamoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PrestamoDto>>> GetPrestamos()
        {
            var prestamos = await _context.Prestamos
                .Select(p => new PrestamoDto
                {
                    Id = p.Id,
                    ClientesId = p.ClientesId,
                    Monto = p.Monto,
                    PlazoMeses = p.PlazoMeses,
                    TasaInteres = p.TasaInteres,
                    TotalAPagar = p.TotalAPagar,
                    EstaPagado = p.EstaPagado
                }).ToListAsync();

            return prestamos;
        }

        // GET: api/Prestamoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Prestamo>> GetPrestamo(int id)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);

            if (prestamo == null)
            {
                return NotFound();
            }

            return prestamo;
        }


        // POST: api/Prestamoes
        [HttpPost]
        public async Task<ActionResult<PrestamoDto>> PostPrestamo(PrestamoCreateDto dto)
        {
            if (!new[] { 6, 12, 18, 24 }.Contains(dto.PlazoMeses))
                return BadRequest("Plazo no válido. Debe ser 6, 12, 18 o 24 meses.");

            decimal tasaDecimal = dto.TasaInteres / 100;
            decimal total = dto.Monto * (decimal)Math.Pow((double)(1 + tasaDecimal), dto.PlazoMeses);

            var prestamo = new Prestamo
            {
                ClientesId = dto.ClientesId,
                Monto = dto.Monto,
                PlazoMeses = dto.PlazoMeses,
                TasaInteres = dto.TasaInteres,
                TotalAPagar = Math.Round(total, 2),
                EstaPagado = false
            };

            _context.Prestamos.Add(prestamo);
            await _context.SaveChangesAsync();

            var prestamoDto = new PrestamoDto
            {
                Id = prestamo.Id,
                ClientesId = prestamo.ClientesId,
                Monto = prestamo.Monto,
                PlazoMeses = prestamo.PlazoMeses,
                TasaInteres = prestamo.TasaInteres,
                TotalAPagar = prestamo.TotalAPagar,
                EstaPagado = prestamo.EstaPagado
            };

            return CreatedAtAction(nameof(GetPrestamo), new { id = prestamo.Id }, prestamoDto);
        }

        // PUT: api/Prestamoes/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPrestamo(int id, PrestamoUpdateDto dto)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);

            if (prestamo == null)
                return NotFound();

            if (!new[] { 6, 12, 18, 24 }.Contains(dto.PlazoMeses))
                return BadRequest("Plazo no válido. Debe ser 6, 12, 18 o 24 meses.");

            // Actualizar valores
            prestamo.Monto = dto.Monto;
            prestamo.PlazoMeses = dto.PlazoMeses;
            prestamo.TasaInteres = dto.TasaInteres;
            prestamo.EstaPagado = dto.EstaPagado;

            // Recalcular TotalAPagar con F = P*(1+i)^n
            decimal tasaDecimal = dto.TasaInteres / 100;
            prestamo.TotalAPagar = Math.Round(
                dto.Monto * (decimal)Math.Pow((double)(1 + tasaDecimal), dto.PlazoMeses), 2);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PrestamoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        // DELETE: api/Prestamoes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePrestamo(int id)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);
            if (prestamo == null)
            {
                return NotFound();
            }

            _context.Prestamos.Remove(prestamo);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PrestamoExists(int id)
        {
            return _context.Prestamos.Any(e => e.Id == id);
        }
    }
}
