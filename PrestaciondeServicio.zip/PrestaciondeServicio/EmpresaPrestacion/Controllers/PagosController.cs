﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmpresaPrestacion.Data;
using EmpresaPrestacion.Dtos;
using EmpresaPrestacion.Models;

namespace EmpresaPrestacion.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PagosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public PagosController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Pagos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PagoDto>>> GetPagos()
        {
            return await _context.Pagos
                .Select(p => new PagoDto
                {
                    Id = p.Id,
                    PrestamoId = p.PrestamoId,
                    MontoPagado = p.MontoPagado,
                    FechaPago = p.FechaPago
                }).ToListAsync();
        }

        // GET: api/Pagos/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PagoDto>> GetPago(int id)
        {
            var pago = await _context.Pagos.FindAsync(id);
            if (pago == null) return NotFound();

            return new PagoDto
            {
                Id = pago.Id,
                PrestamoId = pago.PrestamoId,
                MontoPagado = pago.MontoPagado,
                FechaPago = pago.FechaPago
            };
        }

        // POST: api/Pagos
        [HttpPost]
        public async Task<ActionResult<PagoDto>> PostPago(PagoCreateDto dto)
        {
            var prestamo = await _context.Prestamos.FindAsync(dto.PrestamoId);
            if (prestamo == null) return NotFound("Préstamo no encontrado.");

            var pago = new Pago
            {
                PrestamoId = dto.PrestamoId,
                MontoPagado = dto.MontoPagado,
                FechaPago = DateTime.Now
            };

            _context.Pagos.Add(pago);

            // Calcular total pagado (incluyendo el nuevo pago)
            var totalPagado = await _context.Pagos
                .Where(p => p.PrestamoId == dto.PrestamoId)
                .SumAsync(p => p.MontoPagado) + dto.MontoPagado;

            if (totalPagado >= prestamo.TotalAPagar)
            {
                prestamo.EstaPagado = true;
            }

            await _context.SaveChangesAsync();

            var pagoDto = new PagoDto
            {
                Id = pago.Id,
                PrestamoId = pago.PrestamoId,
                MontoPagado = pago.MontoPagado,
                FechaPago = pago.FechaPago
            };

            return CreatedAtAction(nameof(GetPago), new { id = pago.Id }, pagoDto);
        }

        // PUT: api/Pagos/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPago(int id, PagoUpdateDto dto)
        {
            var pago = await _context.Pagos.FindAsync(id);
            if (pago == null) return NotFound();

            pago.MontoPagado = dto.MontoPagado;

            var prestamo = await _context.Prestamos.FindAsync(pago.PrestamoId);
            if (prestamo == null) return NotFound("Préstamo relacionado no encontrado.");

            await _context.SaveChangesAsync();

            // Recalcular total pagado para ese préstamo
            var totalPagado = await _context.Pagos
                .Where(p => p.PrestamoId == pago.PrestamoId)
                .SumAsync(p => p.MontoPagado);

            prestamo.EstaPagado = totalPagado >= prestamo.TotalAPagar;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Pagos/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePago(int id)
        {
            var pago = await _context.Pagos.FindAsync(id);
            if (pago == null) return NotFound();

            _context.Pagos.Remove(pago);

            var prestamo = await _context.Prestamos.FindAsync(pago.PrestamoId);
            await _context.SaveChangesAsync();

            // Recalcular estado del préstamo
            if (prestamo != null)
            {
                var totalPagado = await _context.Pagos
                    .Where(p => p.PrestamoId == prestamo.Id)
                    .SumAsync(p => p.MontoPagado);

                prestamo.EstaPagado = totalPagado >= prestamo.TotalAPagar;
                await _context.SaveChangesAsync();
            }

            return NoContent();
        }
    }
}
